const monitores = [

    {
        marca: "Philips",
        modelo: "241V8L/55",
        tamaño: 24,
        precio: 29500
    },
    {
        marca: "LG",
        modelo: "24GN600-B 144Hz",
        tamaño: 24,
        precio: 65100
    },
    {
        marca: "LG",
        modelo: "27MK400H-B",
        tamaño: 27,
        precio: 42800
    }
]